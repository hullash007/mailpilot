"""MailPilot package."""
